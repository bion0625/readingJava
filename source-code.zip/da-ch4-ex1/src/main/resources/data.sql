INSERT INTO product VALUES (1, 'beer', 5, 100);
INSERT INTO product VALUES (2, 'coke', 2, 40);
INSERT INTO product VALUES (3, 'lemonade', 10, 1);
INSERT INTO product VALUES (4, 'chocolate', 6, null);
INSERT INTO product VALUES (5, 'candy', 4, 250);